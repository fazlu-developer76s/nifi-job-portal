<div class="modal-dialog modal-dialog-centered"> 
    <!-- Modal content-->
    <div class="modal-content">
    <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">{{__('Add CV')}}</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

        <div class="modal-body">
           <div class="alert alert-success">CV added successfully</div>
        </div>
    </div>
</div>
