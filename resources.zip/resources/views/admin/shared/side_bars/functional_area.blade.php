<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-university" aria-hidden="true"></i> <span class="title">Functional Areas</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="{{ route('list.functional.areas') }}" class="nav-link "> <span class="title">List Functional Areas</span> </a> </li>
        <li class="nav-item  "> <a href="{{ route('create.functional.area') }}" class="nav-link "> <span class="title">Add new Functional Area</span> </a> </li>
    </ul>
</li>