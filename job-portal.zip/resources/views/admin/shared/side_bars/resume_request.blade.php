<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-bar-chart" aria-hidden="true"></i> <span class="title">Resume Request</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="{{ route('list.resume') }}" class="nav-link "> <span class="title">List Resume Request</span> </a> </li>
    </ul>
</li>