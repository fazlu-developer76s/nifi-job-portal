<li class="nav-item  "> <a href="javascript:;" class="nav-link nav-toggle"> <i class="fa fa-money" aria-hidden="true"></i> <span class="title">Packages</span> <span class="arrow"></span> </a>
    <ul class="sub-menu">
        <li class="nav-item  "> <a href="{{ route('list.packages') }}" class="nav-link "> <span class="title">List Packages</span> </a> </li>
        <li class="nav-item  "> <a href="{{ route('create.package') }}" class="nav-link "> <span class="title">Add new Package</span> </a> </li>
    </ul>
</li>