<div class="appwraper">
    <div class="container">
        <div class="row">
            <div class="col-md-5 col-sm-6"> 
                <!--app image Start-->
                <div class="appimg"><img src="{{asset('/')}}images/app-mobile.png" alt="Your alt text here" /></div>
                <!--app image end--> 
            </div>
            <div class="col-md-7 col-sm-6"> 
                <!--app info Start-->
                <div class="titleTop">
                    <div class="subtitle">{{__('Step Forword Now')}}</div>
                    <h3>{{__('The Jobee APP')}}</h3>
                </div>
                <div class="subtitle2">{{__('A world of oppertunity in your hand')}}</div>
                <p>{{__('Aliquam vestibulum cursus felis. In iaculis iaculis sapien ac condimentum. Vestibulum congue posuere lacus, id tincidunt nisi porta sit amet. Suspendisse et sapien varius, pellentesque dui non, semper orci. Curabitur blandit, diam ut ornare ultricies')}}.</p>
                <div class="appbtn">
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-6"><a href="{{url('/')}}"><img src="{{asset('/')}}images/apple-btn.png" alt="Your alt text here"></a></div>
                        <div class="col-md-6 col-sm-6 col-xs-6"><a href="{{url('/')}}"><img src="{{asset('/')}}images/andriod-btn.png" alt="Your alt text here"></a></div>
                    </div>
                </div>
                <!--app info end--> 
            </div>
        </div>
    </div>
</div>
<!-- App End --> 
