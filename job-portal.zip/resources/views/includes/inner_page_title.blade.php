<div class="pageTitle">
    <div class="container">        
                <h1 class="page-heading">{{$page_title}}</h1>
                <div class="breadCrumb"><a href="{{route('index')}}">{{__('Home')}}</a> / <span>{{$page_title}}</span></div>
           
    </div>
</div>