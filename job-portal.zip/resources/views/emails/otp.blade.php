

<!DOCTYPE html>
<html>
<head>
    <title>Your OTP Code</title>
</head>
<body>
    <h1>Your OTP Code</h1>
    <p>Your OTP code is: <strong>{{ $otp }}</strong></p>
    <p>Please use this code to verify your email address.</p>
</body>
</html>
